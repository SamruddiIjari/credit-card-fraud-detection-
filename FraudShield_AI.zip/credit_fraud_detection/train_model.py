"""
train_model.py — Full Credit Card Fraud Detection Training Pipeline
Run: python train_model.py
"""

import os, json, pickle, warnings
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split, StratifiedKFold, cross_val_score
from sklearn.preprocessing import RobustScaler
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (classification_report, confusion_matrix, roc_auc_score,
    precision_recall_curve, average_precision_score, f1_score, roc_curve)
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

warnings.filterwarnings('ignore')
os.makedirs('models', exist_ok=True)
os.makedirs('plots', exist_ok=True)

print("=" * 60)
print("  FraudShield AI — Model Training Pipeline")
print("=" * 60)

# ── 1. Load Data ─────────────────────────────────────────────────
print("\n[1/6] Loading dataset...")
df = pd.read_csv('data/creditcard.csv')
print(f"  Shape: {df.shape}")
print(f"  Fraudulent: {df['Class'].sum()} ({df['Class'].mean()*100:.2f}%)")
print(f"  Legitimate: {(df['Class']==0).sum()}")

# ── 2. Feature Engineering ────────────────────────────────────────
print("\n[2/6] Engineering features...")
df['Amount_log']    = np.log1p(df['Amount'])
df['Hour']          = (df['Time'] / 3600).astype(int) % 24
df['Amount_zscore'] = (df['Amount'] - df['Amount'].mean()) / df['Amount'].std()
df['V1_V2']         = df['V1'] * df['V2']
df['V3_V4']         = df['V3'] * df['V4']
df['V14_V17']       = df['V14'] * df['V17']

feature_cols = [f'V{i}' for i in range(1, 29)] + ['Amount_log', 'Hour', 'Amount_zscore', 'V1_V2', 'V3_V4', 'V14_V17']
X = df[feature_cols]
y = df['Class']
print(f"  Features: {len(feature_cols)}")

# ── 3. Split & Balance ────────────────────────────────────────────
print("\n[3/6] Splitting & balancing data...")
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, stratify=y, random_state=42)

# Oversample minority class manually
fraud_idx = X_train[y_train == 1].index
target_count = len(y_train[y_train == 0]) // 4
n_over = max(0, target_count - len(fraud_idx))
if n_over > 0:
    idx = np.random.choice(fraud_idx, size=n_over, replace=True)
    X_train = pd.concat([X_train, X_train.loc[idx]])
    y_train = pd.concat([y_train, y_train.loc[idx]])

print(f"  Train: {X_train.shape} | Fraud: {y_train.sum()}")
print(f"  Test:  {X_test.shape}  | Fraud: {y_test.sum()}")

# Scale
scaler = RobustScaler()
X_train_sc = scaler.fit_transform(X_train)
X_test_sc  = scaler.transform(X_test)

# ── 4. Train Models ───────────────────────────────────────────────
print("\n[4/6] Training models...")

models = {
    'RandomForest': RandomForestClassifier(
        n_estimators=200, max_depth=12, min_samples_leaf=2,
        class_weight='balanced', random_state=42, n_jobs=-1),
    'GradientBoosting': GradientBoostingClassifier(
        n_estimators=150, max_depth=5, learning_rate=0.1,
        subsample=0.8, random_state=42),
    'LogisticRegression': LogisticRegression(
        C=0.1, class_weight='balanced', max_iter=1000, random_state=42)
}

results = {}
trained = {}

for name, model in models.items():
    print(f"  Training {name}...", end='', flush=True)
    model.fit(X_train_sc, y_train)
    trained[name] = model

    y_pred = model.predict(X_test_sc)
    y_prob = model.predict_proba(X_test_sc)[:, 1]

    auc = roc_auc_score(y_test, y_prob)
    ap  = average_precision_score(y_test, y_prob)
    f1  = f1_score(y_test, y_pred)
    cm  = confusion_matrix(y_test, y_pred).tolist()

    fpr, tpr, _ = roc_curve(y_test, y_prob)
    prec, rec, _ = precision_recall_curve(y_test, y_prob)

    results[name] = {
        'auc': round(auc, 4), 'ap': round(ap, 4), 'f1': round(f1, 4),
        'cm': cm,
        'roc': {'fpr': fpr[:50].tolist(), 'tpr': tpr[:50].tolist()},
        'pr':  {'prec': prec[:50].tolist(), 'rec': rec[:50].tolist()}
    }
    print(f" ✓  AUC={auc:.4f}  AP={ap:.4f}  F1={f1:.4f}")

# Ensemble
rf_p  = trained['RandomForest'].predict_proba(X_test_sc)[:, 1]
gb_p  = trained['GradientBoosting'].predict_proba(X_test_sc)[:, 1]
lr_p  = trained['LogisticRegression'].predict_proba(X_test_sc)[:, 1]
ens_p = (rf_p + gb_p + lr_p) / 3.0
ens_y = (ens_p > 0.4).astype(int)

ens_auc = roc_auc_score(y_test, ens_p)
ens_ap  = average_precision_score(y_test, ens_p)
ens_f1  = f1_score(y_test, ens_y)
ens_cm  = confusion_matrix(y_test, ens_y).tolist()
e_fpr, e_tpr, _ = roc_curve(y_test, ens_p)
e_prec, e_rec, _ = precision_recall_curve(y_test, ens_p)

results['Ensemble'] = {
    'auc': round(ens_auc, 4), 'ap': round(ens_ap, 4), 'f1': round(ens_f1, 4),
    'cm': ens_cm,
    'roc': {'fpr': e_fpr[:50].tolist(), 'tpr': e_tpr[:50].tolist()},
    'pr':  {'prec': e_prec[:50].tolist(), 'rec': e_rec[:50].tolist()}
}
print(f"  Ensemble:         AUC={ens_auc:.4f}  AP={ens_ap:.4f}  F1={ens_f1:.4f}")

# ── 5. Feature Importance ─────────────────────────────────────────
print("\n[5/6] Computing feature importance...")
fi = pd.Series(trained['RandomForest'].feature_importances_, index=feature_cols)
fi_sorted = fi.sort_values(ascending=False).head(15)
feature_importance = {
    'features': fi_sorted.index.tolist(),
    'scores':   fi_sorted.values.round(4).tolist()
}

# ── 6. Save Artifacts ─────────────────────────────────────────────
print("\n[6/6] Saving models & metrics...")
pickle.dump(trained['RandomForest'],    open('models/random_forest.pkl', 'wb'))
pickle.dump(trained['GradientBoosting'],open('models/gradient_boosting.pkl', 'wb'))
pickle.dump(trained['LogisticRegression'],open('models/logistic_regression.pkl', 'wb'))
pickle.dump(scaler,                     open('models/scaler.pkl', 'wb'))

json.dump({
    'results': results,
    'feature_cols': feature_cols,
    'feature_importance': feature_importance
}, open('models/metrics.json', 'w'), indent=2)

# Plots
plt.figure(figsize=(12, 5))
plt.subplot(1, 2, 1)
colors = {'RandomForest': '#00d4ff', 'GradientBoosting': '#7c3aed',
          'LogisticRegression': '#ffa500', 'Ensemble': '#00e676'}
for name, d in results.items():
    plt.plot(d['roc']['fpr'], d['roc']['tpr'], label=f"{name} ({d['auc']})", color=colors[name])
plt.plot([0,1],[0,1],'k--',alpha=.3)
plt.xlabel('FPR'); plt.ylabel('TPR'); plt.title('ROC Curves'); plt.legend()

plt.subplot(1, 2, 2)
names_bar = list(results.keys())
aucs = [results[n]['auc'] for n in names_bar]
plt.barh(names_bar, aucs, color=[colors[n] for n in names_bar])
plt.xlabel('ROC-AUC'); plt.title('Model Comparison'); plt.xlim(0, 1)
plt.tight_layout()
plt.savefig('plots/model_comparison.png', dpi=150, bbox_inches='tight')
print("  Plots saved to plots/")

print("\n" + "=" * 60)
print("  Training Complete!")
print("=" * 60)
for name, d in results.items():
    print(f"  {name:25s} AUC={d['auc']}  AP={d['ap']}  F1={d['f1']}")
print()
