"""
generate_dataset.py — Synthetic Credit Card Fraud Dataset Generator

Generates a realistic 10,000-row dataset with:
- 28 PCA-transformed features (V1-V28) simulating real card data
- Time, Amount columns
- ~2% fraud rate (Class=1)

Run: python generate_dataset.py
"""

import numpy as np
import pandas as pd
from sklearn.datasets import make_classification
import os

np.random.seed(42)
os.makedirs('data', exist_ok=True)

print("Generating synthetic credit card fraud dataset...")

N = 10000
FRAUD_RATIO = 0.02

X, y = make_classification(
    n_samples=N,
    n_features=28,
    n_informative=15,
    n_redundant=5,
    n_clusters_per_class=2,
    weights=[1 - FRAUD_RATIO, FRAUD_RATIO],
    flip_y=0,
    random_state=42
)

df = pd.DataFrame(X, columns=[f'V{i}' for i in range(1, 29)])

# Realistic time (seconds from start)
df.insert(0, 'Time', np.random.exponential(scale=3600, size=N).cumsum())

# Amount: fraud tends to be higher or very low
df['Amount'] = np.where(
    y == 1,
    np.random.choice([
        np.random.exponential(scale=200, size=N),
        np.random.uniform(0.5, 5, size=N)          # smurfing attacks
    ], p=[0.7, 0.3]),
    np.random.exponential(scale=80, size=N)
)
df['Amount'] = np.clip(df['Amount'], 0.5, 5000).round(2)
df['Class']  = y

# Add realistic variance
for col in [f'V{i}' for i in range(1, 29)]:
    df[col] = (df[col] * np.random.uniform(0.7, 1.3, size=N)).round(6)

df = df.sort_values('Time').reset_index(drop=True)
df.to_csv('data/creditcard.csv', index=False)

fraud_count = df['Class'].sum()
print(f"  Saved: data/creditcard.csv")
print(f"  Total: {len(df):,} transactions")
print(f"  Fraud: {fraud_count} ({fraud_count/len(df)*100:.2f}%)")
print(f"  Legit: {len(df)-fraud_count:,}")
print(f"  Columns: {list(df.columns)}")
print("Done!")
