# 🛡️ FraudShield AI — Credit Card Fraud Detection System

An end-to-end machine learning project that detects fraudulent credit card transactions using an ensemble of 3 ML models, served via a real-time Flask web dashboard.

---

## 📁 Project Structure

```
credit_fraud_detection/
│
├── app.py                  ← Flask web application (REST API + UI)
├── train_model.py          ← Full training pipeline
├── generate_dataset.py     ← Synthetic dataset generator
├── requirements.txt        ← Python dependencies
│
├── data/
│   └── creditcard.csv      ← Dataset (10,000 transactions, ~2% fraud)
│
├── models/
│   ├── random_forest.pkl       ← Trained Random Forest
│   ├── gradient_boosting.pkl   ← Trained Gradient Boosting
│   ├── logistic_regression.pkl ← Trained Logistic Regression
│   ├── scaler.pkl              ← RobustScaler
│   └── metrics.json            ← All model metrics & curves
│
├── templates/
│   └── index.html          ← Web dashboard UI
│
├── plots/                  ← Auto-generated performance charts
└── notebooks/              ← (optional) Jupyter analysis
```

---

## 🚀 Quick Start — Run in VS Code

### Step 1: Open VS Code

Open VS Code. Press `Ctrl+`` `` ` `` to open the integrated terminal.

---

### Step 2: Create & Navigate to Project Folder

```bash
# Windows
cd %USERPROFILE%\Desktop
mkdir credit_fraud_detection
cd credit_fraud_detection

# Mac / Linux
cd ~/Desktop
mkdir credit_fraud_detection
cd credit_fraud_detection
```

---

### Step 3: Copy Project Files

Extract the downloaded ZIP into this folder. Your structure should match the tree above.

---

### Step 4: Create a Virtual Environment

```bash
# Create virtual environment
python -m venv venv

# Activate it
# Windows:
venv\Scripts\activate
# Mac/Linux:
source venv/bin/activate
```

You should see `(venv)` in your terminal prompt.

---

### Step 5: Install Dependencies

```bash
pip install -r requirements.txt
```

> ⏱ This takes ~2-3 minutes. All packages will be installed.

---

### Step 6: Generate Dataset (if not present)

```bash
python generate_dataset.py
```

Output:
```
Generating synthetic credit card fraud dataset...
  Saved: data/creditcard.csv
  Total: 10,000 transactions
  Fraud: 200 (2.00%)
```

---

### Step 7: Train the Models

```bash
python train_model.py
```

Output:
```
[1/6] Loading dataset...
[2/6] Engineering features...
[3/6] Splitting & balancing data...
[4/6] Training models...
  Training RandomForest...  ✓  AUC=0.9720  AP=0.5687  F1=0.3529
  Training GradientBoosting... ✓  AUC=0.9811  AP=0.8173  F1=0.5862
  Training LogisticRegression... ✓  AUC=0.9297  AP=0.5700  F1=0.2116
  Ensemble:   AUC=0.9623  AP=0.6886  F1=0.6437
[5/6] Computing feature importance...
[6/6] Saving models & metrics...
Training Complete!
```

---

### Step 8: Launch the Web App

```bash
python app.py
```

Then open your browser and go to: **http://localhost:5000**

---

## 🖥️ Using the Dashboard

### 🔍 Detect Tab
- **Load Sample Transactions** — Click `⚠ Fraud #1` or `✓ Legit #1` buttons to auto-fill a real transaction
- **Manual Input** — Edit V1-V28, Amount, Hour fields
- **Analyze Transaction** — Click the button to get real-time predictions from all 3 models + ensemble
- **Results** show: Risk Level (HIGH/MEDIUM/LOW), confidence scores per model, visual bars

### 📊 Analytics Tab
- Full model comparison table (AUC, AP, F1)
- Confusion matrices for all models
- ROC curves overlay for all 4 models
- Bar chart comparison

### 📖 API Docs Tab
- REST API examples with `curl` commands
- Response format documentation

---

## 🔌 REST API

### Predict Transaction

```bash
curl -X POST http://localhost:5000/predict \
  -H "Content-Type: application/json" \
  -d '{
    "V1": -1.36, "V2": 0.27, "V3": 0.09,
    "V4": 1.24, "V5": 0.49, "V6": 0.22,
    "V7": 0.08, "V8": 0.08, "V9": 0.08,
    "V10": 0.08, "V11": 0.08, "V12": 0.08,
    "V13": 0.08, "V14": 0.08, "V15": 0.08,
    "V16": 0.08, "V17": 0.08, "V18": 0.08,
    "V19": 0.08, "V20": 0.08, "V21": 0.08,
    "V22": 0.08, "V23": 0.08, "V24": 0.08,
    "V25": 0.08, "V26": 0.08, "V27": 0.08,
    "V28": 0.08, "Amount": 149.62, "Hour": 14
  }'
```

**Response:**
```json
{
  "is_fraud": false,
  "risk_level": "LOW",
  "ensemble_score": 12.5,
  "model_scores": {
    "RandomForest": 10.2,
    "GradientBoosting": 14.3,
    "LogisticRegression": 13.0,
    "Ensemble": 12.5
  },
  "amount": 149.62
}
```

### Get Metrics
```bash
curl http://localhost:5000/api/metrics
```

### Get Sample Transactions
```bash
curl http://localhost:5000/api/samples
```

---

## 🧠 ML Architecture

### Models Used

| Model | Role | Key Params |
|-------|------|-----------|
| **Random Forest** | High recall, stable | 200 trees, depth 12, balanced weights |
| **Gradient Boosting** | Best precision | 150 estimators, lr=0.1, depth 5 |
| **Logistic Regression** | Interpretable baseline | C=0.1, balanced weights |
| **Ensemble (Soft Vote)** | Best overall | Average of all 3 probabilities |

### Feature Engineering

- `Amount_log` — log1p(Amount) to reduce skew
- `Hour` — transaction hour from Time field
- `Amount_zscore` — standardized amount
- `V1_V2`, `V3_V4`, `V14_V17` — interaction features

### Class Imbalance Strategy
- Manual oversampling of fraud class (replicate to 25% of majority)
- `class_weight='balanced'` in tree-based models
- Ensemble threshold tuned to 0.4 (not default 0.5)

### Model Performance (on held-out test set)

| Model | ROC-AUC | Avg Precision | F1 |
|-------|---------|--------------|-----|
| Random Forest | 0.9720 | 0.5687 | 0.3529 |
| Gradient Boosting | **0.9811** | **0.8173** | 0.5862 |
| Logistic Regression | 0.9297 | 0.5700 | 0.2116 |
| **Ensemble** | 0.9623 | 0.6886 | **0.6437** |

---

## 📦 Dependencies

```
flask          ← Web framework
numpy          ← Numerical computing
pandas         ← Data manipulation
scikit-learn   ← ML models & preprocessing
matplotlib     ← Plotting
seaborn        ← Statistical visualization
imbalanced-learn ← SMOTE oversampling (optional upgrade)
xgboost        ← XGBoost model (optional upgrade)
```

---

## 🔧 Troubleshooting

**Port 5000 in use:**
```bash
python app.py  # change port in app.py last line: port=5001
```

**Module not found:**
```bash
pip install -r requirements.txt
```

**Models not found:**
```bash
python train_model.py  # retrain
```

**Dataset not found:**
```bash
python generate_dataset.py  # regenerate
```

---

## 🚀 Upgrade Path

To use XGBoost and SMOTE (requires `pip install xgboost imbalanced-learn`):

1. In `train_model.py`, add:
```python
from xgboost import XGBClassifier
from imblearn.over_sampling import SMOTE

sm = SMOTE(random_state=42)
X_res, y_res = sm.fit_resample(X_train_sc, y_train)

xgb = XGBClassifier(n_estimators=200, max_depth=6, learning_rate=0.05,
    scale_pos_weight=50, use_label_encoder=False, eval_metric='aucpr')
xgb.fit(X_res, y_res)
```

---

## 📄 License

MIT License — free to use and modify.
