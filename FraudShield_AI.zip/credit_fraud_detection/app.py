import os, json, pickle, numpy as np, pandas as pd
from flask import Flask, render_template, request, jsonify
import warnings; warnings.filterwarnings('ignore')

app = Flask(__name__)

# Load models
BASE = os.path.dirname(__file__)
scaler = pickle.load(open(os.path.join(BASE, 'models/scaler.pkl'), 'rb'))
rf     = pickle.load(open(os.path.join(BASE, 'models/random_forest.pkl'), 'rb'))
gb     = pickle.load(open(os.path.join(BASE, 'models/gradient_boosting.pkl'), 'rb'))
lr     = pickle.load(open(os.path.join(BASE, 'models/logistic_regression.pkl'), 'rb'))
metrics = json.load(open(os.path.join(BASE, 'models/metrics.json')))

FEATURE_COLS = metrics['feature_cols']

def engineer_features(raw: dict) -> np.ndarray:
    v = [float(raw.get(f'V{i}', 0)) for i in range(1, 29)]
    amount = float(raw.get('Amount', 0))
    hour   = int(raw.get('Hour', 12))
    amount_log    = np.log1p(amount)
    amount_zscore = (amount - 94.0) / 160.0
    v1_v2  = v[0] * v[1]
    v3_v4  = v[2] * v[3]
    v14_v17 = v[13] * v[16]
    return np.array(v + [amount_log, hour, amount_zscore, v1_v2, v3_v4, v14_v17]).reshape(1, -1)

def predict_ensemble(features_sc):
    p_rf = rf.predict_proba(features_sc)[0][1]
    p_gb = gb.predict_proba(features_sc)[0][1]
    p_lr = lr.predict_proba(features_sc)[0][1]
    ensemble = (p_rf + p_gb + p_lr) / 3.0
    return {'RandomForest': round(p_rf,4), 'GradientBoosting': round(p_gb,4),
            'LogisticRegression': round(p_lr,4), 'Ensemble': round(ensemble,4)}

@app.route('/')
def index():
    return render_template('index.html', metrics=metrics)

@app.route('/predict', methods=['POST'])
def predict():
    data = request.json
    features = engineer_features(data)
    features_sc = scaler.transform(features)
    probs = predict_ensemble(features_sc)
    ensemble_score = probs['Ensemble']
    is_fraud = ensemble_score > 0.4
    risk_level = 'HIGH' if ensemble_score > 0.7 else 'MEDIUM' if ensemble_score > 0.4 else 'LOW'
    return jsonify({
        'is_fraud': bool(is_fraud),
        'risk_level': risk_level,
        'ensemble_score': round(ensemble_score * 100, 2),
        'model_scores': {k: round(v*100, 2) for k,v in probs.items()},
        'amount': data.get('Amount', 0),
    })

@app.route('/api/metrics')
def get_metrics():
    return jsonify(metrics)

@app.route('/api/samples')
def get_samples():
    df = pd.read_csv(os.path.join(BASE, 'data/creditcard.csv'))
    fraud = df[df['Class']==1].sample(5, random_state=1)
    legit = df[df['Class']==0].sample(5, random_state=1)
    samples = []
    for _, row in pd.concat([fraud, legit]).iterrows():
        s = {f'V{i}': round(row[f'V{i}'], 4) for i in range(1, 29)}
        s['Amount'] = round(row['Amount'], 2)
        s['Hour'] = int(row.get('Hour', 12)) if 'Hour' in row else 12
        s['Class'] = int(row['Class'])
        samples.append(s)
    return jsonify(samples)

if __name__ == '__main__':
    app.run(debug=True, port=5000)
